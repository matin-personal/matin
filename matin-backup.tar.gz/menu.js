function toggleMenu() {
  const menu = document.getElementById("menuItems");
  menu.classList.toggle("open");
}
